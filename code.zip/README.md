# Tracking corner detection

The code runs in main, contains a csv_reader file and corner_detect.